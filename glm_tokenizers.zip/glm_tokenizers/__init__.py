import os
from .base_tokenizer import BaseTokenizer
from .sentencepiece_tokenizer import SentencePieceTokenizer
from .tiktoken_tokenizer import TikTokenizer

resource_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources")

vocab_file_mapping = {
    "65k-tokenizer": os.path.join(resource_dir, "65k_tokenizer.model"),
    "llama-tokenizer": os.path.join(resource_dir, "llama_tokenizer.model"),
    "55k-tokenizer": os.path.join(resource_dir, "55k_tokenizer.model"),
    "130k-tokenizer": os.path.join(resource_dir, "130k_tokenizer.tiktoken"),
    "150k-tokenizer": os.path.join(resource_dir, "150k_tokenizer.tiktoken")
}

tokenizer_type_mapping = {
    "65k-tokenizer": SentencePieceTokenizer,
    "llama-tokenizer": SentencePieceTokenizer,
    "55k-tokenizer": SentencePieceTokenizer,
    "130k-tokenizer": TikTokenizer,
    "150k-tokenizer": TikTokenizer,
}

tokenizer = None


def get_tokenizer(name=None) -> BaseTokenizer:
    global tokenizer
    if name is None:
        assert tokenizer is not None
        return tokenizer
    else:
        if not name.endswith("-tokenizer"):
            name = name + "-tokenizer"
        if name in vocab_file_mapping:
            vocab_file = vocab_file_mapping[name]
            tokenizer_class = tokenizer_type_mapping[name]
            tokenizer = tokenizer_class(vocab_file=vocab_file)
            return tokenizer
        else:
            raise NotImplemented(name)
