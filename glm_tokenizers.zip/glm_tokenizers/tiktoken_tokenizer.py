from .base_tokenizer import BaseTokenizer
import regex as re
import base64
import tiktoken


class TikTokenizer(BaseTokenizer):
    def __init__(self, vocab_file=None):
        super().__init__()
        pat_str = "(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?\\p{L}+|\\p{N}{1,3}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+"
        self.pat_str = re.compile(pat_str)

        if vocab_file is not None:
            mergeable_ranks = {}
            with open(vocab_file) as f:
                for line in f:
                    token, rank = line.strip().split()
                    rank = int(rank)
                    token = base64.b64decode(token)
                    mergeable_ranks[token] = rank

        self.special_tokens = ["<|endoftext|>", "[MASK]", "[gMASK]", "[sMASK]", "<sop>", "<eop>", "<|system|>",
                               "<|user|>", "<|assistant|>", "<|observation|>", "<|begin_of_image|>", "<|end_of_image|>",
                               "<|begin_of_video|>", "<|end_of_video|>"]

        self.special_tokens = {
            token: idx for idx, token in enumerate(self.special_tokens, start=len(mergeable_ranks))
        }
        self.special_token_ids = {idx: token for token, idx in self.special_tokens.items()}

        self.tokenizer = tiktoken.Encoding(
            name="my_tokenizer",
            pat_str=pat_str,
            mergeable_ranks=mergeable_ranks,
            special_tokens=self.special_tokens
        )
        self.decoder = {rank: token for token, rank in mergeable_ranks.items()}
        self.n_words = len(self.decoder) + len(self.special_tokens)

    @property
    def add_prefix_space(self):
        return True

    def tokenize(self, text, encode_special_tokens=False, add_dummy_prefix=False):
        if encode_special_tokens:
            return self.tokenizer.encode(text, allowed_special="all")
        else:
            return self.tokenizer.encode(text, disallowed_special=())

    def detokenize(self, ids, ignore_special_tokens=True):
        if ignore_special_tokens:
            ids = [idx for idx in ids if idx not in self.special_token_ids]
        return self.tokenizer.decode(ids)

    def encode_pieces(self, text):
        ids = self.tokenizer.encode(text, disallowed_special=())
        return list(map(lambda x: self.decoder[x].detokenize('utf-8', errors='replace'), ids))

    @property
    def vocab_size(self):
        return self.n_words

    @property
    def eos_id(self):
        return self.special_tokens["<|endoftext|>"]

    def convert_token_to_id(self, token):
        """ Converts a token (str) in an id using the vocab. """
        if token in self.special_tokens:
            return self.special_tokens[token]
        ids = self.tokenizer.encode(token, disallowed_special=())
        if len(ids) == 1:
            return ids[0]
        else:
            raise RuntimeError(f"{token} is not a single token")

    def convert_id_to_token(self, index):
        if index in self.special_token_ids:
            return self.special_token_ids[index]
        return self.decoder[index].detokenize('utf-8', errors='replace')

    def get_special_token(self, token):
        return self.special_tokens[token]
