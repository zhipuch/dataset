import os
import re
from typing import List
from sentencepiece import SentencePieceProcessor
from .base_tokenizer import BaseTokenizer


class SentencePieceTokenizer(BaseTokenizer):
    def __init__(self, vocab_file):
        super().__init__()
        # reload tokenizer
        assert os.path.isfile(vocab_file), vocab_file
        self.sp_model = SentencePieceProcessor(model_file=vocab_file)
        self.noprefix_sp_model = SentencePieceProcessor(model_file=vocab_file + ".noprefix")

        # BOS / EOS token IDs
        self.n_words: int = self.sp_model.vocab_size()
        self._bos_id: int = self.sp_model.bos_id()
        self._eos_id: int = self.sp_model.eos_id()
        self._pad_id: int = self.sp_model.pad_id()
        assert self.sp_model.vocab_size() == self.sp_model.get_piece_size()

        special_tokens = ["[MASK]", "[gMASK]", "[sMASK]", "<sop>", "<eop>", "<|system|>", "<|user|>", "<|assistant|>",
                          "<|observation|>", "<|begin_of_image|>", "<|end_of_image|>", "<|begin_of_video|>",
                          "<|end_of_video|>"]
        self.special_tokens = {}
        self.special_token_ids = {}
        for token in special_tokens:
            self.special_tokens[token] = self.n_words
            self.special_token_ids[self.n_words] = token
            self.n_words += 1
        self.special_tokens["<|endoftext|>"] = self._eos_id
        self.special_tokens["<bos>"] = self._bos_id
        self.special_token_ids[self._eos_id] = "<|endoftext|>"
        self.special_token_ids[self._bos_id] = "<bos>"
        self.special_token_expression = "|".join([re.escape(token) for token in self.special_tokens])

    def tokenize(self, s: str, encode_special_tokens=False, add_dummy_prefix=True) -> List[int]:
        if add_dummy_prefix:
            model = self.sp_model
        else:
            model = self.noprefix_sp_model
        assert type(s) is str
        if encode_special_tokens:
            last_index = 0
            t = []
            for match in re.finditer(self.special_token_expression, s):
                if last_index < match.start():
                    t.extend(model.EncodeAsIds(s[last_index:match.start()]))
                t.append(self.convert_token_to_id(s[match.start():match.end()]))
                last_index = match.end()
            if last_index < len(s):
                t.extend(model.EncodeAsIds(s[last_index:]))
            return t
        else:
            t = model.EncodeAsIds(s)
        return t

    def detokenize(self, t: List[int], ignore_special_tokens=True) -> str:
        text, buffer = "", []
        for token in t:
            if token in self.special_token_ids:
                if buffer:
                    text += self.sp_model.decode(buffer)
                    buffer = []
                if not ignore_special_tokens:
                    text += self.special_token_ids[token]
            else:
                buffer.append(token)
        if buffer:
            text += self.sp_model.decode(buffer)
        return text

    def convert_token_to_id(self, token):
        """ Converts a token (str) in an id using the vocab. """
        if token in self.special_tokens:
            return self.special_tokens[token]
        return self.sp_model.PieceToId(token)

    def convert_id_to_token(self, index):
        if index in self.special_token_ids:
            return self.special_token_ids[index]
        return self.sp_model.IdToPiece(index)

    @property
    def vocab_size(self):
        return self.n_words

    @property
    def eos_id(self):
        return self._eos_id

    def get_special_token(self, token):
        return self.special_tokens[token]
