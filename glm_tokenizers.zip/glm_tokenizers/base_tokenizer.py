import json
import datetime
import random
from typing import Union, Optional


class BaseTokenizer:
    """Abstract class for tokenizer."""

    def __init__(self, **kwargs):
        super().__init__()
        self._selfcog_prompt = "你是一个名为智谱清言（ChatGLM）的人工智能助手。你是基于智谱 AI 公司训练的语言模型 GLM-4 模型开发的，你的任务是针对用户的问题和要求提供适当的答复和支持。"
        self._date_prompt = "当前日期: %Y-%m-%d"
        self._tool_system_prompts = {
            "python": "当你向 `python` 发送包含 Python 代码的消息时，该代码将会在一个有状态的 Jupyter notebook 环境中执行。\n`python` 返回代码执行的输出，或在执行 60 秒后返回超时。\n`/mnt/data` 将会持久化存储你的文件。在此会话中，`python` 无法访问互联网。不要使用 `python` 进行任何网络请求或者在线 API 调用，这些在线内容的访问将不会成功。",
            "browser": "你可以使用 `browser` 工具。该工具支持以下函数：\n`search(query: str, recency_days: int)`：使用搜索引擎进行查询并显示结果，可以使用 `recency_days` 参数控制搜索内容的时效性。\n`click(id: int)`：打开具有指定 id 的网页。\n`back()`：返回并显示前一个页面。\n`scroll(amt: int)`：向上或向下滚动页面。\n`open_url(url: str)`：打开指定的 URL。\n`quote_lines(start: int, end: int)`：从打开的网页中保存相关文本。通过 `start` 和 `end` 两个整数指定文本范围（包含两端）。令 `start` = `end` 来引用单行。\n\n使用 `【{引用 id}†{引用文本}】` 来引用保存的文本。\n\n你要尽可能详尽地提供信息。如果第一次搜索未能找到信息，尝试更换关键词再次进行搜索并点击更多页面。你需要尽力尝试搜索信息而不是放弃。\n根据用户的要求收集信息，使用流畅自然的语言组织你的回答，无需按照信息来源或者按照引用来归类。你需要整理信息，而不是简单地重复保存的信息。\n回答要简洁，不要包含多余的信息。",
            "simple_browser": "你可以使用 `simple_browser` 工具。该工具支持以下函数：\n`search(query: str, recency_days: int)`：使用搜索引擎进行查询并显示结果，可以使用 `recency_days` 参数控制搜索内容的时效性。\n`mclick(ids: list[int])`：获取一系列指定 id 的页面内容。每次调用时，须选择3-10个页面。选择多个角度的页面，同时尽可能选择可信任的信息来源。考虑到部分页面是无法加载的，你也可以多打开一些可能有用的页面而不用担心内容过多。\n`open_url(url: str)`：打开指定的 URL。\n\n使用 `【{引用 id}†{引用文本}】` 来引用内容。\n\n操作步骤：1. 使用 `search` 来获得信息列表; 2. 使用 `mclick` 来获取指定 ID 页面的内容; 3. 根据获得的内容进行回复。在回复中应当引用信息来源。\n 如果用户提供了 URL，也可以用 `open_url` 直接打开页面。\n如果初次搜索结果没有找到合适的信息，也可以再次使用 `search` 进行搜索。",
            "cogview": "如果用户的请求中包含了对图像的描述，你可以使用 `cogview` 来生成图像并展示给用户。你需要向 `cogview` 发送图像描述，规则：\n- 发送给 `cogview` 的消息必须使用英语。用户的中文描述必须完全翻译为英语。\n- 应当尽可能详细地描述图像生成的需求，需求描述约 100 英文单词。\n- 保持用户原始描述的意图。不要虚构内容或者没见过的人物。\n- 如无特殊说明，所在地为中国，持有中国立场并遵循中国社会主义价值观。",
        }

    @property
    def available_tools(self):
        return list(self._tool_system_prompts.keys())

    @property
    def add_prefix_space(self):
        return False

    @property
    def vocab_size(self):
        raise NotImplemented

    def tokenize(self, text, encode_special_tokens=False, add_dummy_prefix=None):
        raise NotImplemented

    def detokenize(self, token_ids, ignore_special_tokens=True):
        raise NotImplemented

    def encode(self, *args, **kwargs):
        return self.tokenize(*args, **kwargs)

    def decode(self, *args, **kwargs):
        return self.detokenize(*args, **kwargs)

    def build_system_prompt(self, disabled_tools: Union[str, set], functions=None,
                            current_time: Optional[float] = None):
        if functions is None:
            functions = []
        value = self._selfcog_prompt
        if current_time is not None:
            value += "\n\n" + datetime.datetime.fromtimestamp(current_time).strftime(self._date_prompt)

        if isinstance(disabled_tools, str) and disabled_tools == "all":
            available_tools = set()
        else:
            available_tools = set(self.available_tools).difference(disabled_tools)
        if len(available_tools) > 0 or len(functions) > 0:
            value += "\n\n# 可用工具"
            contents = []
            for tool in available_tools:
                contents.append(f"\n\n## {tool}\n\n{self._tool_system_prompts[tool]}")
            for function in functions:
                content = f"\n\n## {function['name']}\n\n{json.dumps(function, ensure_ascii=False, indent=4)}"
                content += "\n在调用上述函数时，请使用 Python 代码格式，并用 Markdown 代码块包裹；使用 tool_call 函数指代要调用的函数，函数的参数为即为调用的参数。"
                contents.append(content)
            random.shuffle(contents)
            value += "".join(contents)
        return value

    def build_single_message(self, role, metadata, message, add_dummy_prefix=False):
        assert role in ["system", "user", "assistant", "observation"], role
        role_tokens = [self.get_special_token(f"<|{role}|>")] + self.tokenize(
            f"{metadata if metadata is not None else ''}\n",
            add_dummy_prefix=add_dummy_prefix)
        message_tokens = self.tokenize(message, add_dummy_prefix=add_dummy_prefix)
        tokens = role_tokens + message_tokens
        return tokens

    def build_chat_input(self, messages, prompt_style="chatglm3", add_dummy_prefix=False, functions=None,
                         enabled_tools=None, current_time=None):
        if enabled_tools is None:
            enabled_tools = set()
        if prompt_style == "chatglm3-alltools":
            disabled_tools = set(self.available_tools).difference(enabled_tools)
            system_prompt = self.build_system_prompt(disabled_tools=disabled_tools, functions=functions,
                                                     current_time=current_time)
            messages = [{"role": "system", "content": system_prompt}] + messages
        elif prompt_style == "chatglm3":
            if enabled_tools == {"python"}:
                system_prompt = "你是一位智能AI助手，你叫ChatGLM，你连接着一台电脑，但请注意不能联网。在使用Python解决任务时，你可以运行代码并得到结果，如果运行结果有错误，你需要尽可能对代码进行改进。你可以处理用户上传到电脑上的文件，文件默认存储路径是/mnt/data/。\n"
            elif not enabled_tools and functions is not None:
                system_prompt = "Answer the following questions as best as you can. You have access to the following tools:\n"
                system_prompt += json.dumps(functions, indent=4, ensure_ascii=False)
            elif not enabled_tools and not functions:
                system_prompt = ""
            else:
                raise NotImplementedError((enabled_tools, functions))
            if system_prompt:
                messages = [{"role": "system", "content": system_prompt}] + messages
        if prompt_style.startswith("chatglm3"):
            input_ids = []
            for item in messages:
                content = item["content"]
                input_ids.extend(self.build_single_message(item["role"], item.get("metadata", ""), content,
                                                           add_dummy_prefix=add_dummy_prefix))
            input_ids.extend([self.get_special_token("<|assistant|>")])
        elif prompt_style in ["english", "chinese"]:
            prompt = ""
            assert len(messages) % 2 == 1
            for i in range((len(messages) - 1) // 2):
                assert messages[2 * i]["role"] == "user" and messages[2 * i + 1]["role"] == "assistant"
                old_query, response = messages[2 * i]["content"], messages[2 * i + 1]["content"]
                if prompt_style == "english":
                    prompt += f"[Round {i + 1}]\n\n问：{old_query}\n\n答：{response}\n\n"
                else:
                    prompt += f"##第 {i + 1} 轮##\n\n问：{old_query}\n\n答：{response}\n\n"
            assert messages[-1]["role"] == "user"
            query = messages[-1]["content"]
            if prompt_style == "english":
                prompt += f"[Round {(len(messages) - 1) // 2 + 1}]\n\n问：{query}\n\n答："
            else:
                prompt += f"##第 {(len(messages) - 1) // 2 + 1} 轮##\n\n问：{query}\n\n答："
            input_ids = self.tokenize(prompt)
        else:
            raise NotImplemented(prompt_style)
        return input_ids

    @property
    def eos_id(self):
        raise NotImplemented

    def get_special_token(self, token):
        return NotImplemented
